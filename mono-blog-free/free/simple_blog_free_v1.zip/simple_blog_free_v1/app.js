// ---------- 유틸 ----------
const $ = (sel, ctx=document) => ctx.querySelector(sel);
const $$ = (sel, ctx=document) => Array.from(ctx.querySelectorAll(sel));

const KEY_USER = 'mono_user';
const KEY_POSTS = 'mono_posts'; // [{id, title, content, author, ts, comments:[{text, author, ts}]}]

const now = () => new Date().toISOString();

// ---------- 상태 ----------
let user = localStorage.getItem(KEY_USER);
if (!user) {
  // 로그인 안 되어 있으면 로그인 페이지로
  if (!location.href.endsWith('login.html')) location.href = './login.html';
}

// ---------- 헤더 사용자 영역 ----------
const userArea = $('#userArea');
if (userArea) {
  userArea.innerHTML = user
    ? `<span class="muted">${user}</span> <button id="btn-logout" class="ghost">로그아웃</button>`
    : `<a href="./login.html">로그인</a>`;
  const logout = $('#btn-logout');
  if (logout) logout.addEventListener('click', () => {
    localStorage.removeItem(KEY_USER);
    location.href = './login.html';
  });
}

// ---------- 글쓰기 토글 ----------
const editor = $('#editor');
const btnNew = $('#btn-new');
const cancelEdit = $('#cancelEdit');

if (btnNew && editor) {
  btnNew.addEventListener('click', () => editor.classList.toggle('hidden'));
}
if (cancelEdit && editor) {
  cancelEdit.addEventListener('click', () => editor.classList.add('hidden'));
}

// ---------- 데이터 I/O ----------
const readPosts = () => {
  try { return JSON.parse(localStorage.getItem(KEY_POSTS) || '[]'); }
  catch { return []; }
};
const writePosts = (list) => localStorage.setItem(KEY_POSTS, JSON.stringify(list));

// ---------- 글 등록 ----------
const form = $('#postForm');
if (form) {
  form.addEventListener('submit', (e) => {
    e.preventDefault();
    const title = $('#title').value.trim();
    const content = $('#content').value.trim();
    if (!title || !content) return;

    const posts = readPosts();
    const post = {
      id: 'p_' + Date.now(),
      title, content,
      author: user,
      ts: now(),
      comments: []
    };
    posts.unshift(post);
    writePosts(posts);

    form.reset();
    editor.classList.add('hidden');
    renderPosts();
  });
}

// ---------- 글 렌더 ----------
const listEl = $('#postList');
const tpl = $('#postItemTpl');

function renderPosts() {
  if (!listEl) return;
  const posts = readPosts();
  listEl.innerHTML = '';
  posts.forEach(p => {
    const node = tpl.content.cloneNode(true);
    $('.post-title', node).textContent = p.title;
    $('.meta', node).textContent = `${p.author || '익명'} · ${p.ts.slice(0,16).replace('T',' ')}`;
    $('.post-body', node).textContent = p.content;

    const commentsWrap = $('.comments', node);
    const commentList = $('.comment-list', node);
    const toggleBtn = $('.btn-comment-toggle', node);
    const form = $('.comment-form', node);
    const input = $('.comment-input', node);

    // 기존 댓글 렌더
    p.comments.forEach(c => {
      const item = document.createElement('div');
      item.className = 'comment';
      item.textContent = `${c.author || '익명'}: ${c.text}`;
      commentList.appendChild(item);
    });

    toggleBtn.addEventListener('click', () => {
      commentsWrap.classList.toggle('hidden');
    });

    // 댓글 등록
    form.addEventListener('submit', (e) => {
      e.preventDefault();
      const text = input.value.trim();
      if (!text) return;
      const item = document.createElement('div');
      item.className = 'comment';
      item.textContent = `${user || '익명'}: ${text}`;
      commentList.appendChild(item);
      input.value = '';

      // 저장
      const posts = readPosts();
      const idx = posts.findIndex(x => x.id === p.id);
      if (idx >= 0) {
        posts[idx].comments.push({ text, author: user, ts: now() });
        writePosts(posts);
      }
    });

    listEl.appendChild(node);
  });
}

renderPosts();